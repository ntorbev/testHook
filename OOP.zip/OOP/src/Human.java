/**
 * Created by vili on 9/29/2016.
 */
class Human {
    private String first_name;
    private String last_name;

    Human(String first_name, String last_name) {
        this.first_name = first_name;
        this.last_name = last_name;
    }
}
