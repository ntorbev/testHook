package animals;

/**
 * Created by vili on 10/10/2016.
 */
public abstract class Animals {
    private int age;
    private String name;
    private int gender;

    void say(){ }
}
